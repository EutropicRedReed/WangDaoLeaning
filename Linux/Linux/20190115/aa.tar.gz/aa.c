#include<stdio.h>
int main()
{
	int i=0;
	for(;i<3;i++);
	{
		printf("%d\n",i);
	}
	return 0;
}
