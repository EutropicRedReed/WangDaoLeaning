#include <stdio.h>

int add(int,int);

int main()
{
	printf("result=%d\n",add(3,4));
	return 0;
}
