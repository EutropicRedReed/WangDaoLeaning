#include <stdio.h>
#define N 3+2
