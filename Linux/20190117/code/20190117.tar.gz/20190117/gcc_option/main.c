#include "func.h"
//void print();
int main()
{
	int iNum=N*N;
	printf("iNum=%d\n",iNum);
	int i;
	for(i=0;i<5;i++)
	{
		printf("%d\n",i);
	}
	print();
	print();
	return 0;
}
