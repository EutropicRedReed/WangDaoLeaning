#include <stdio.h>

int main()
{
	char *p=NULL;
	*p='b';
	return 0;
}
