#include <stdio.h>

#define N 3+2
int main()
{
	int iNum=N*N;
	printf("iNum=%d\n",iNum);
	int i;
	for(i=0;i<5;i++)
	{
		printf("%d\n",i);
	}
	return 0;
}
