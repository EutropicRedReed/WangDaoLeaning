#include <stdio.h>
int muti(int a,int b)
{
	printf("muti result=%d\n",a*b);
	return a*b;
}
